<template>
  <div class="rr-tooltip">
    <button class="rr-tooltip__toggle" :class="{'rr-tooltip__toggle--expanded' : showInfo == true}" @click="showTooltip()">
      <span>{{ toggleButtonText }}</span>
    </button>
    <div class="rr-tooltip__details" :class="{'rr-tooltip__details--show' : showInfo}" >
      <button class="rr-tooltip__close" @click="showInfo = !showInfo">Close</button>
      <h5><slot name="tooltip-title"></slot></h5>
      <p><slot name="tooltip-body"></slot></p>
    </div>
  </div>
</template>
<script>
  export default {
    data: function () {
      return {
        showInfo : false
      }
    },
    methods: {
      showTooltip: function() {
        // Hide other tooltips before showing this one.
        if(this.showInfo === false){
          this.$root.$emit('hideTooltips');
        }
        this.showInfo = !this.showInfo;
      }
    },
    mounted: function () { 
      this.$root.$on('hideTooltips', () => { this.showInfo = false });
    },
    props: ['toggleButtonText', 'tooltipText']
  }
</script>