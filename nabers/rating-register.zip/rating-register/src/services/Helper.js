export default class Helper {

  oneDP (value) {
    if (value.indexOf('.') > -1)
      value = Number.parseFloat(value).toFixed(1);
    return value;
  }
}
