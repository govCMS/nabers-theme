export default class Filter {
  constructor () {
    this.ratingFields = [
      'PremiseType',
      'RatingType',
      'RatingScope',
      'StarRating',
      'CarbonNeutral'
    ]
  }

  /**
   *
   * @param {Array} dataArray
   * @param {Array} filters
   */
  filterData (dataArray, filters) {
    if (filters.length > 0) {
      return dataArray.filter(item => {
        let passedTests = 0

        // Test data against filters.
        for (let i = 0; i < filters.length; i++) {
          let filter = filters[i]
          let isCarbonNeutralFilter = filter.field.toLowerCase().indexOf('carbon') > -1 ? true : false
          let filterValue = isCarbonNeutralFilter ? [] : filter.value.map(item => item.toLowerCase())
          if (this.ratingFields.indexOf(filter.field) >= 0 && item.Ratings.length > 0) {
            // Search within ratings (any positive will result in a passed test)
            for (let j = 0; j < item.Ratings.length; j++) {
              let rating = item.Ratings[j]
              // Nested if statement required because CarbonNeutral can be false, but we don't want it to fall
              // through to else because error will be thrown trying .toLowerCase() the boolean
              if (isCarbonNeutralFilter) {
                if (rating[filter.field] == true) {
                  passedTests++
                  break
                }
              }
              else if (filterValue.indexOf(rating[filter.field].toLowerCase()) >= 0) {
                passedTests++
                break
              }
            }
          } else {
            // For searching on root of object.
            if (item.hasOwnProperty(filter.field) && filterValue.indexOf(item[filter.field].toLowerCase()) >= 0) {
              passedTests++
            }
          }
        }

        return (passedTests === filters.length)
      })
    } else {
      return dataArray
    }
  }
}
